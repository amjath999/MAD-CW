package com.example.flight_booking_app;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class ActivityFlightDetails extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flight_details); // Ensure this XML exists
    }
}
